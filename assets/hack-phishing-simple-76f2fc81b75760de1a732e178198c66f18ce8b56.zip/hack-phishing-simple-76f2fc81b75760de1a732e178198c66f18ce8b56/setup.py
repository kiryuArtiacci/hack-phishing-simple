## INFO: Colors
BG_COLOR = '#0F172A'
FG_COLOR = '#E2E8F0'
ENTRY_BG = '#1E293B'
BUTTON_BG = '#334155'
ACCENT_COLOR = '#9333EA'
ACCENT_ACTIVE = '#A855F7'
FONT_NORMAL = ('Segoe UI', 10)
FONT_BOLD = ('Segoe UI', 10, 'bold')
FONT_TITLE = ('Segoe UI', 16, 'bold')
FONT_MENU_TITLE = ('Segoe UI', 12, 'bold')


# <div className="min-h-screen w-full relative">
#   {/* Radial Gradient Background */}
#   <div
#     className="absolute inset-0 z-0"
#     style={{
#       background: "radial-gradient(125% 125% at 50% 10%, #fff 40%, #6366f1 100%)",
#     }}
#   />
#      {/* Your Content/Components */}
# </div>
