# Talentos Asociados (Nombre WIP)
~~MCP Hiring Group~~

---
Usando TKinter

